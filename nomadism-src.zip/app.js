// Main Application Orchestrator for Silkroad Platform
(function() {
  let curLang = 'ko';
  let audioCtx = null;

  function playBeep(freq = 880, duration = 0.05, type = 'sine') {
    try {
      if (!audioCtx) {
        audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      }
      if (audioCtx.state === 'suspended') {
        audioCtx.resume();
      }
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      
      osc.type = type;
      osc.frequency.setValueAtTime(freq, audioCtx.currentTime);
      
      gain.gain.setValueAtTime(0.04, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + duration);
      
      osc.start();
      osc.stop(audioCtx.currentTime + duration);
    } catch (e) {}
  }

  function triggerGlitchEffect() {
    const crt = document.querySelector('.crt-interference');
    if (crt) {
      crt.classList.add('screen-glitch');
      playBeep(260, 0.06, 'sawtooth');
      setTimeout(() => playBeep(580, 0.05, 'sine'), 50);
      setTimeout(() => {
        crt.classList.remove('screen-glitch');
      }, 300);
    }
  }

  function initLobbyRadar() {
    const canvas = document.getElementById('lobby-radar-canvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    let W = canvas.width = window.innerWidth;
    let H = canvas.height = window.innerHeight;
    
    let mouse = { x: W * 0.75, y: H * 0.5 };
    let radarWaves = [];
    let lastWaveTime = 0;
    
    window.addEventListener('resize', () => {
      W = canvas.width = window.innerWidth;
      H = canvas.height = window.innerHeight;
    });
    
    const lobbyEl = document.getElementById('page-lobby');
    if (lobbyEl) {
      lobbyEl.addEventListener('mousemove', (e) => {
        mouse.x = e.clientX;
        mouse.y = e.clientY;
      });
    }
    
    function drawRadar() {
      if (lobbyEl && lobbyEl.style.display === 'none') {
        requestAnimationFrame(drawRadar);
        return;
      }
      
      ctx.clearRect(0, 0, W, H);
      
      const now = Date.now();
      if (now - lastWaveTime > 1400) {
        radarWaves.push({ r: 10, maxR: Math.max(W, H) * 0.6, o: 0.28 });
        lastWaveTime = now;
      }
      
      ctx.strokeStyle = 'rgba(250, 246, 240, 0.03)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.arc(mouse.x, mouse.y, 80, 0, Math.PI * 2);
      ctx.arc(mouse.x, mouse.y, 180, 0, Math.PI * 2);
      ctx.stroke();
      
      ctx.strokeStyle = 'rgba(250, 246, 240, 0.06)';
      ctx.beginPath();
      ctx.moveTo(mouse.x - 12, mouse.y);
      ctx.lineTo(mouse.x + 12, mouse.y);
      ctx.moveTo(mouse.x, mouse.y - 12);
      ctx.lineTo(mouse.x, mouse.y + 12);
      ctx.stroke();
      
      ctx.lineWidth = 1.5;
      radarWaves.forEach((w, i) => {
        ctx.strokeStyle = `rgba(250, 246, 240, ${w.o})`;
        ctx.beginPath();
        ctx.arc(mouse.x, mouse.y, w.r, 0, Math.PI * 2);
        ctx.stroke();
        
        w.r += 1.8;
        w.o -= 0.0012;
        
        if (w.r >= w.maxR || w.o <= 0) {
          radarWaves.splice(i, 1);
        }
      });
      
      requestAnimationFrame(drawRadar);
    }
    drawRadar();
  }

  function t(key) {
    const LOCALES = window.LOCALES || {};
    return LOCALES[curLang]?.[key] || LOCALES['ko']?.[key] || key;
  }

  function triggerToast(msg, type = 'info') {
    const icons = { info: 'ℹ️', success: '✅', warning: '⚠️', error: '❌' };
    const el = document.createElement('div');
    el.className = 'toast';
    el.textContent = (icons[type] || '') + ' ' + msg;
    const toastsWrap = document.getElementById('toasts');
    if (toastsWrap) {
      toastsWrap.appendChild(el);
    }
    setTimeout(() => {
      el.style.transition = 'all .25s';
      el.style.opacity = '0';
      el.style.transform = 'scale(.9)';
      setTimeout(() => el.remove(), 260);
    }, 3000);
  }

  function setLang(l) {
    curLang = l;
    document.getElementById('html-root').lang = l;

    // Language button activation
    ['ko', 'en', 'ru'].forEach(code => {
      const btn = document.getElementById('lang-' + code);
      if (btn) btn.classList.toggle('active', code === l);
      const lobbyBtn = document.getElementById('lang-' + code + '-lobby');
      if (lobbyBtn) {
        lobbyBtn.style.color = (code === l) ? '#FAF6F0' : 'rgba(250, 246, 240, 0.45)';
        lobbyBtn.style.fontWeight = (code === l) ? '900' : '800';
      }
    });

    // Update DOM translation
    document.querySelectorAll('[data-i18n]').forEach(el => {
      const v = t(el.dataset.i18n);
      if (v) el.textContent = v;
    });

    document.querySelectorAll('[data-i18n-ph]').forEach(el => {
      const v = t(el.dataset.i18nPh);
      if (v) el.placeholder = v;
    });

    document.querySelectorAll('[data-i18n-opt]').forEach(el => {
      const v = t(el.dataset.i18nOpt);
      if (v) el.textContent = v;
    });

    // Re-render sub-components
    window.StoreModule.buildStoreCards(t, triggerToast);
    window.CommunityModule.renderPosts(t);
    window.ExchangeModule.updateFXInfoUI(t);
    window.WeatherModule.renderWeather(t, curLang);
    window.ExchangeModule.calcDutchpayDetailed(t);
  }

  function switchTab(id) {
    triggerGlitchEffect();
    
    if (id === 'lobby') {
      playBeep(440, 0.08, 'sawtooth');
      setTimeout(() => playBeep(520, 0.08, 'sawtooth'), 60);
    } else {
      playBeep(660, 0.04, 'sine');
      setTimeout(() => playBeep(880, 0.04, 'sine'), 40);
    }

    setTimeout(() => {
      document.querySelectorAll('.tab-content').forEach(e => e.classList.remove('active'));
      const lobbyEl = document.getElementById('page-lobby');
      
      if (id === 'lobby') {
        if (lobbyEl) lobbyEl.style.display = 'flex';
      } else {
        if (lobbyEl) lobbyEl.style.display = 'none';
        const page = document.getElementById('page-' + id);
        if (page) page.classList.add('active');
      }
      
      if (id === 'main') {
        setTimeout(() => {
          const mapMain = window.MapModule.getMapMain();
          if (mapMain) mapMain.invalidateSize();
        }, 150);
      }
      
      const floatWidget = document.getElementById('float-widget');
      if (floatWidget) {
        floatWidget.style.display = (id !== 'exchange' && id !== 'lobby' && window.ExchangeModule.isFloatActive()) ? 'block' : 'none';
      }
    }, 150);
  }

  // Drag & Drop for Currency Float Widget
  function initFloatWidget() {
    const floatEl = document.getElementById('float-widget');
    const floatH = document.getElementById('float-header');
    if (!floatEl || !floatH) return;

    let dragging = false, ox = 0, oy = 0;

    floatH.addEventListener('mousedown', e => {
      dragging = true;
      ox = e.clientX - floatEl.offsetLeft;
      oy = e.clientY - floatEl.offsetTop;
      floatEl.style.transition = 'none';
    });

    document.addEventListener('mousemove', e => {
      if (!dragging) return;
      floatEl.style.left = (e.clientX - ox) + 'px';
      floatEl.style.top = (e.clientY - oy) + 'px';
      floatEl.style.right = 'auto';
    });

    document.addEventListener('mouseup', () => { dragging = false; });
  }

  function closeFloat() {
    const floatEl = document.getElementById('float-widget');
    if (floatEl) floatEl.style.display = 'none';
    window.ExchangeModule.setFloatActive(false);
  }

  function saveOffline() {
    triggerToast(t('toast.offline.start'), 'info');
    setTimeout(() => triggerToast(t('toast.offline.done'), 'success'), 1800);
  }

  function onFXDropdownChange() {
    // Force conversion update based on anchor KRW value
    window.ExchangeModule.triggerUIExchange(t);
  }

  // Global initialization
  window.addEventListener('DOMContentLoaded', () => {
    // 1. Initialize Maps
    window.MapModule.initMaps();

    // 2. Initialize Weather
    window.WeatherModule.loadWeather(t, curLang);

    // 3. Initialize Community Posts from local storage
    window.CommunityModule.initPosts();

    // 4. Render Components
    setLang('ko');
    initLobbyRadar();

    // 5. Setup Drag Widget
    initFloatWidget();

    // 6. Bind Real-time Rate sync button
    const syncBtn = document.getElementById('sync-rates-btn');
    if (syncBtn) {
      syncBtn.addEventListener('click', () => {
        window.ExchangeModule.syncRealtimeRates(triggerToast, t);
      });
    }

    // 7. Bind FX Dropdown changes
    ['main-g1-sel', 'main-g2-sel', 'main-l1-sel', 'main-l2-sel'].forEach(id => {
      const selectEl = document.getElementById(id);
      if (selectEl) {
        selectEl.addEventListener('change', onFXDropdownChange);
      }
    });

    // 8. Bind hover/click tactical sounds to lobby items & buttons
    document.querySelectorAll('.lobby-menu-item').forEach(btn => {
      btn.addEventListener('mouseenter', () => playBeep(880, 0.04));
    });
    document.querySelectorAll('.lobby-back-btn, .btn, button').forEach(btn => {
      btn.addEventListener('mouseenter', () => playBeep(980, 0.02));
    });
  });

  // Network status listeners
  window.addEventListener('offline', () => {
    const banner = document.getElementById('offline-banner');
    if (banner) banner.style.display = 'block';
  });
  window.addEventListener('online', () => {
    const banner = document.getElementById('offline-banner');
    if (banner) banner.style.display = 'none';
    triggerToast(t('toast.net.back'), 'success');
  });

  // PWA Registration
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('/service-worker.js').catch(err => {
        console.warn("ServiceWorker registration failed:", err);
      });
    });
  }

  // Nomadism Payment Center Modal Handlers
  function openPaymentModal(name, price, cur) {
    document.getElementById('pay-item-name').textContent = name;
    document.getElementById('pay-item-price').textContent = price;
    document.getElementById('pay-item-cur').textContent = cur;
    document.getElementById('pay-user-name').value = '';
    document.getElementById('pay-user-email').value = '';
    document.getElementById('pay-agree-terms').checked = false;
    document.getElementById('pay-agree-cancel').checked = false;
    switchPayMethod('kakao');  // 기본 탭
    document.getElementById('modal-payment').classList.add('open');
    document.body.style.overflow = 'hidden';
  }

  function closePaymentModal() {
    document.getElementById('modal-payment').classList.remove('open');
    document.body.style.overflow = 'auto';
  }

  // 랜덤 QR 토큰 생성 (가상 결제 URL용)
  function makeQrToken() {
    return Math.random().toString(36).substring(2, 14).toUpperCase();
  }
  function makeQrUrl(prefix) {
    const token = makeQrToken();
    const payload = `${prefix}://pay?token=${token}&t=${Date.now()}`;
    return `https://api.qrserver.com/v1/create-qr-code/?size=140x140&data=${encodeURIComponent(payload)}&bgcolor=ffffff&color=000000`;
  }

  const TAB_BRAND = {
    kakao:  { ringColor: '#FEE500' },
    naver:  { ringColor: '#03C75A' },
    toss:   { ringColor: '#0064FF' },
    paypal: { ringColor: '#003087' }
  };

  function switchPayMethod(method) {
    // Reset all tabs — keep their native bg, just remove ring
    document.querySelectorAll('.pay-method-tab').forEach(b => {
      b.style.outline = 'none';
      b.style.boxShadow = 'none';
      b.style.opacity = '0.72';
    });
    // Highlight active tab with a glow ring
    const activeTab = document.getElementById(`pay-tab-${method}`);
    if (activeTab) {
      const brand = TAB_BRAND[method] || {};
      activeTab.style.outline = `2.5px solid ${brand.ringColor || '#60a5fa'}`;
      activeTab.style.boxShadow = `0 0 0 3px ${(brand.ringColor || '#60a5fa')}44`;
      activeTab.style.opacity = '1';
    }
    // Show panel
    document.querySelectorAll('.pay-panel').forEach(p => p.style.display = 'none');
    const activePanel = document.getElementById(`pay-panel-${method}`);
    if (activePanel) activePanel.style.display = 'block';

    // Generate random QR code for this payment method
    const qrImg = document.getElementById(`qr-${method}`);
    if (qrImg) {
      qrImg.src = makeQrUrl(method);
      qrImg.onerror = () => {
        qrImg.parentElement.innerHTML = `<div style="width:140px;height:140px;display:flex;align-items:center;justify-content:center;background:#f0f0f0;border-radius:8px;color:#333;font-size:11px;text-align:center;padding:10px;">QR 생성 중...</div>`;
      };
    }
  }

  function submitPayment() {
    const name  = document.getElementById('pay-user-name').value.trim();
    const email = document.getElementById('pay-user-email').value.trim();
    const agree1 = document.getElementById('pay-agree-terms').checked;
    const agree2 = document.getElementById('pay-agree-cancel').checked;

    if (!name || !email) {
      triggerToast('예약자 성명과 이메일을 입력해주세요.', 'warning');
      return;
    }
    if (!agree1 || !agree2) {
      triggerToast('필수 약관 및 환불 규정에 동의하셔야 합니다.', 'warning');
      return;
    }

    triggerToast('결제 처리 중입니다...', 'info');
    setTimeout(() => {
      triggerToast('결제가 정상 완료되었습니다! 이메일 바우처를 확인하세요.', 'success');
      closePaymentModal();
    }, 1800);
  }

  // Expose app namespace globally to index.html inline listeners
  window.app = {
    t,
    triggerToast,
    setLang,
    switchTab,
    closeFloat,
    saveOffline,
    
    // payment modal redirect
    openPaymentModal,
    closePaymentModal,
    switchPayMethod,
    submitPayment,
    
    // map.js redirect
    toggleSatellite: () => window.MapModule.toggleSatellite(triggerToast, t),
    onCityChange: () => window.MapModule.onCityChange(),
    generateItinerary: () => window.MapModule.generateItinerary(t, curLang, triggerToast),
    loadGoldenRoute: (routeKey) => window.MapModule.loadGoldenRoute(routeKey, t, curLang, triggerToast),
    closeModal: () => window.MapModule.closeModal(),
    flyToLocation: (cityName) => window.MapModule.flyToLocation(cityName),
    
    // exchange.js redirect
    convertCurrency: (from, val) => window.ExchangeModule.convertCurrency(from, val, t),
    calcDutchpay: () => window.ExchangeModule.calcDutchpayDetailed(t),
    syncRealtimeRates: () => window.ExchangeModule.syncRealtimeRates(triggerToast, t),
    addExpenseItem: () => window.ExchangeModule.addExpenseItem(t),
    deleteExpenseItem: (itemId) => window.ExchangeModule.deleteExpenseItem(itemId, t),
    
    // store.js redirect
    filterStore: (code, btn) => window.StoreModule.filterStore(code, btn),
    
    // community.js redirect
    addComment: (postId, tFn) => window.CommunityModule.addComment(postId, tFn),
    toggleCommentLike: (postId, commentId, btn) => window.CommunityModule.toggleLike(postId, commentId, btn),
    toggleWriteForm: () => window.CommunityModule.toggleWriteForm(),
    submitPost: () => window.CommunityModule.submitPost(t),
    triggerCommentAuth: (postId, commentId, mode) => window.CommunityModule.showCommentAuth(postId, commentId, mode),
    hideCommentAuth: (commentId) => window.CommunityModule.hideCommentAuth(commentId),
    submitCommentAuth: (postId, commentId, tFn) => window.CommunityModule.submitCommentAuth(postId, commentId, tFn),
    saveCommentEdit: (postId, commentId, tFn) => window.CommunityModule.saveCommentEdit(postId, commentId, tFn),
    cancelCommentEdit: (postId) => window.CommunityModule.cancelCommentEdit(postId),
    savePostEdit: (postId, tFn) => window.CommunityModule.savePostEdit(postId, tFn),
    cancelPostEdit: (postId) => window.CommunityModule.cancelPostEdit(postId)
  };
})();
